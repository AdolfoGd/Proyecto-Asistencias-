﻿using Application.DTOs;
using Application.Interface;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Application.Service
{
    public class AsistenciaService
    {
        private readonly IAsistenciaRepository _asistenciaRepository;

        private static List<AsistenciaDTO> _baseDeDatosVisual = new List<AsistenciaDTO>();

        public AsistenciaService(IAsistenciaRepository asistenciaRepository)
        {
            _asistenciaRepository = asistenciaRepository;
        }

        public async Task<IEnumerable<AsistenciaDTO>> ListarAsistencia()
        {
            return await Task.FromResult(_baseDeDatosVisual);
        }

        public async Task<IEnumerable<AsistenciaDTO>> ListarAsistenciasPorSesion(int idsesion)
        {
            var filtrados = _baseDeDatosVisual.Where(a => a.IdSesion == idsesion).ToList();
            return await Task.FromResult(filtrados);
        }

        public async Task NuevaAsistencia(AsistenciaDTO a)
        {
            a.IdAsistencia = _baseDeDatosVisual.Count > 0 ? _baseDeDatosVisual.Max(x => x.IdAsistencia) + 1 : 1;

            _baseDeDatosVisual.Add(a);

            await Task.CompletedTask;
        }

        public async Task EditarAsistencia(AsistenciaDTO a)
        {
            var existente = _baseDeDatosVisual.FirstOrDefault(x => x.IdAsistencia == a.IdAsistencia);
            if (existente != null)
            {
                existente.Estado = a.Estado;
                existente.Hora_Registro = a.Hora_Registro;
            }
            await Task.CompletedTask;
        }

        public async Task EliminarAsistencia(AsistenciaDTO a)
        {
            var existente = _baseDeDatosVisual.FirstOrDefault(x => x.IdAsistencia == a.IdAsistencia);
            if (existente != null)
            {
                _baseDeDatosVisual.Remove(existente);
            }
            await Task.CompletedTask;
        }
    }
}