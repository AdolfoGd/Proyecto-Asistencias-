﻿using Application.DTOs;
using Application.Service;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers
{
    public class AsistenciasController : Controller
    {
        private readonly AsistenciaService _asistenciaService;

        public AsistenciasController(AsistenciaService asistenciaService)
        {
            _asistenciaService = asistenciaService;
        }

        [HttpGet]
        public async Task<IActionResult> Index(int? idSesion)
        {
            ViewBag.IdSesionBuscada = idSesion;

            if (idSesion.HasValue)
            {
                var resultados = await _asistenciaService.ListarAsistenciasPorSesion(idSesion.Value);
                return View(resultados);
            }

            var todas = await _asistenciaService.ListarAsistencia();
            return View(todas);
        }

        [HttpGet]
        public IActionResult NuevoAsistencia()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> NuevoAsistencia(AsistenciaDTO asistenciaDto)
        {
            if (ModelState.IsValid)
            {
                await _asistenciaService.NuevaAsistencia(asistenciaDto);
                return RedirectToAction(nameof(Index));
            }

            return View(asistenciaDto);
        }
    }
}