﻿using Application.Interface;
using Domain.Entities;
using Infraestructure.DataBase;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Infraestructure.Repository
{
    public class AsistenciaRepository : IAsistenciaRepository
    {
        private readonly DBConnectionFactory _connectionFactory;

        public AsistenciaRepository(DBConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public async Task<IEnumerable<Asistencia>> ListarAsistenciaAsync()
        {
            var lista = new List<Asistencia>();
            using (MySqlConnection conn = (MySqlConnection)_connectionFactory.CreateConnection())
            {
                using (MySqlCommand cmd = new MySqlCommand("sp_LeerAsistencias", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    await conn.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var asistencia = new Asistencia
                            {
                                IdAsistencia = reader.GetInt32("IdAsistencia"),
                                IdSesion = reader.GetInt32("IdSesion"),
                                Carnet = Convert.ToInt32(reader["Carnet"]), 
                                Estado = reader.GetString("Estado"),
                                Hora_Registro = reader.IsDBNull(reader.GetOrdinal("Hora_Registro"))
                                                ? new TimeOnly()
                                                : TimeOnly.FromTimeSpan((TimeSpan)reader["Hora_Registro"])
                            };
                            lista.Add(asistencia);
                        }
                    }
                }
                return lista;
            }
        }

        public async Task<IEnumerable<Asistencia>> ListarAsistenciaPorSesionAsync(int idsesion)
        {
            var lista = new List<Asistencia>();
            using (MySqlConnection con = (MySqlConnection)_connectionFactory.CreateConnection())
            {
                using (MySqlCommand cmd = new MySqlCommand("sp_LeerAsistenciaPorSesion", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("idSesion", idsesion);

                    await con.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var asistencia = new Asistencia
                            {
                                IdAsistencia = reader.GetInt32("IdAsistencia"),
                                IdSesion = reader.GetInt32("IdSesion"),
                                Carnet = Convert.ToInt32(reader["Carnet"]),
                                Estado = reader.GetString("Estado"),
                                Hora_Registro = reader.IsDBNull(reader.GetOrdinal("Hora_Registro"))
                                                ? new TimeOnly()
                                                : TimeOnly.FromTimeSpan((TimeSpan)reader["Hora_Registro"])
                            };
                            lista.Add(asistencia);
                        }
                    }
                }
                return lista;
            }
        }

        public async Task NuevaAsistenciaAsync(Asistencia asistencia)
        {
            using var con = (MySqlConnection)_connectionFactory.CreateConnection();
            await con.OpenAsync();

            try
            {
                using var cmd = new MySqlCommand("sp_InsertarAsistencia", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("idSesion", asistencia.IdSesion);
                cmd.Parameters.AddWithValue("carnet", asistencia.Carnet.ToString()); 
                cmd.Parameters.AddWithValue("estado", asistencia.Estado);
                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Error al guardar en la base de datos: " + ex.Message);
            }
        }

        public async Task EditarAsistenciaAsync(Asistencia asistencia)
        {
            throw new NotImplementedException();
        }

        public Task EliminarAsistenciaAsync(int id)
        {
            throw new NotImplementedException();
        }
    }
}